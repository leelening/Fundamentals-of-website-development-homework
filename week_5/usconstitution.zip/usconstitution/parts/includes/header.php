  <header role="banner">
    <h1>The United States Constitution: <?php echo ($article) ?></h1>
  </header>