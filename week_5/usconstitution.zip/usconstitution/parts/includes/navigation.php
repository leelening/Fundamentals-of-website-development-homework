<nav role="navigation">
    <ul id="mainnav">
      <li id="navpart1"><a href="index.php">Article I</a></li>
      <li id="navpart2"><a href="ii.php">Article II</a></li>
      <li id="navpart3"><a href="iii.php">Article III</a></li>
      <li id="navpart4"><a href="iv.php">Article IV</a></li>
      <li id="navpart5"><a href="v.php">Article V</a></li>
      <li id="navpart6"><a href="vi.php">Article VI</a></li>
      <li id="navpart7"><a href="vii.php">Article VII</a></li>
      <li id="navpart8"><a href="amendments.php">Amendments</a></li>
    </ul>
</nav>