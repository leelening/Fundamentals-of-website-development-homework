<footer id="footer">
    <div class="center-block col-md-3">
        <p>Supported by <a href="http://lening.li">Lening Li</a>
            <br/>32 1/2 John Street
            <br/>Worcester, MA 01609
            <br/>(774) 823-2639
        </p>
    </div>
    <div class="col-md-9">
        <?php include("social-navigation.php"); ?>
    </div>
</footer>
