<nav role="navigation" id="tech-nav">
    <ul>
        <li>
            <ul>
                <li>Android Development</li>
                <li>Assemble Language</li>
                <li>Visual Basic</li>
                <li>C</li>
                <li>C++</li>
                <li>C#</li>
                <li>Cascading Style Sheets(CSS)</li>
                <li>HTML</li>
                <li>Java</li>
                <li>JavaScript</li>
                <li>Matlab</li>
                <li>Microsoft Foundation Class(MFC)</li>
                <li>Structured Query Language(SQL)</li>
                <li>Python</li>
                <li>Verilog</li>
            </ul>
        </li>
        <li>
            <ul>
                <li>Ubuntu(Linux)</li>
                <li>OS X</li>
                <li>Windows</li>
            </ul>
        </li>
        <li>
            <ul>
                <li>Vim</li>
                <li>Git</li>
                <li>Emacs</li>
                <li>Brackets</li>
                <li>PowerBuilder</li>
                <li>Microsoft SQL Server</li>
                <li>Eclipse</li>
                <li>Visual Studio 2010</li>
                <li>QT Creator</li>
                <li>Open Rave</li>
                <li>Robotics Operating System</li>
                <li>Modelsim</li>
                <li>Gazebo</li>
                <li>IxChariot</li>
                <li>Pohtoshop</li>
                <li>Lightroom</li>
                <li>Dreamweaver</li>
            </ul>
        </li>
    </ul>

</nav>
