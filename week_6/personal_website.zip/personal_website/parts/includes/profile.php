<div id="profile">
    <img src="../images/profile.jpg" class="img-circle" alt="image">

    <br/>Graduate Student in CS

    <br/>Worcester Polytechnic Institute

    <br/>Location: Worcester, Massachusetts

    <br/>Telephone: (774) 823-2639

    <br/>Resume: <a href="http://lening.li/about/LeningLiRESUME(CS).pdf" class="fa fa-file-pdf-o"> PDF</a>
    
    <?php include("social-navigation.php"); ?>
</div>
