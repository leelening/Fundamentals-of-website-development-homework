<nav role="navigation" id="site-nav" class="center-block">
    <ul>
        <li id="navpart1"><a href="index.php" class="fa fa-home">Homepage</a></li>
        <li id="navpart2"><a href="personal.php" class="fa fa-user">About Me</a></li>
        <li id="navpart3"><a href="traveled_places.php" class="fa fa-map-marker">Traveled Places</a></li>
        <li id="navpart4"><a href="post.php" class="fa fa-heart">Post</a></li>
        <li id="navpart5"><a href="tech_blog.php" class="fa fa-desktop">Technical Blog</a></li>
        <li id="navpart6"><a href="search.php" class="fa fa-search">Search</a></li>
    </ul>
</nav>
