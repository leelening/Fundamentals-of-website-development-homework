<!-- Gallery -->
<fieldset id="gallery">
    <legend>Travelling photos</legend>
</fieldset>
