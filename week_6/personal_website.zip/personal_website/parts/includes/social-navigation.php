<div class="social-icons">
    <ul role="navigation">
        <a href="http://twitter.com/LeeLening" title="Lening Li on Twitter" target="_blank"><i class="fa fa-twitter-square fa-2x"></i></a>
        <a href="http://facebook.com/profile.php?id=100002505753214" title="Lening Li on Facebook" target="_blank"><i class="fa fa-facebook-square fa-2x"></i></a>

        <a href="https://www.linkedin.com/pub/lening-li/a5/a28/a74" title="Lening Li on LinkedIn" target="_blank"><i class="fa fa-linkedin-square fa-2x"></i></a>

        <a href="http://instagram.com/leelening" title="Lening Li on Instagram" target="_blank"><i class="fa fa-instagram fa-2x"></i></a>

        <a href="http://github.com/xiao00li" title="Lening Li on Github" target="_blank"><i class="fa fa-github-square fa-2x"></i></a>
    </ul>
</div>
